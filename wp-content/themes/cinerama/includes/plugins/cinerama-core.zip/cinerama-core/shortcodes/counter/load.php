<?php

include_once CINERAMA_CORE_SHORTCODES_PATH . '/counter/functions.php';
include_once CINERAMA_CORE_SHORTCODES_PATH . '/counter/counter.php';