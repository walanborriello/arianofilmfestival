<?php

include_once CINERAMA_CORE_SHORTCODES_PATH . '/lightbox-image-gallery/functions.php';
include_once CINERAMA_CORE_SHORTCODES_PATH . '/lightbox-image-gallery/lightbox-image-gallery.php';