<?php

include_once 'lib/cinerama-instagram-api.php';
include_once 'widgets/load.php';